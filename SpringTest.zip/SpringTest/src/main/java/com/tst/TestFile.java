package com.tst;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

@CrossOrigin()
@RestController
public class TestFile {
	

	@RequestMapping("/")
	public String index() {
		return "Greetings from Spring Boot!";
	}

	@RequestMapping("/hw")
	public String hw() {
		return "<h1>Hello World</h1>";
	}
	
	@RequestMapping("/dataTest")
	public String dtaTst() {
		return "this is data from the java program";
	}
	
}