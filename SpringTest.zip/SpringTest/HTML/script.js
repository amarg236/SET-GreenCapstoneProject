
const ce = React.createElement; //makes life easier to create elements

function host(txt=""){ //Get the host and append text to it
	return "http://localhost:8080/"+txt
};
//sends off some data to the specified host and fetches the response
//Will execute whatever fnctn is, remember to take and use a parameter
async function sendData(dta, hst="", fnctn=function(a=""){console.log(a)}){
	fd = new FormData() // build a form
	fd.append('nfo', dta); //append data
	//make a response by calling fetch
	v = await fetch(host(hst), {method:'POST', body: fd})
	.then(function(x){return x.text()}).then(function(x){fnctn(x)});//YES doing a .then(function).then(function{call function}) is needed as far as I can figure.
};

class testForm extends React.Component{
	constructor(props){
		super(props);
		this.state=0;
		this.handleChange=this.handleChange.bind(this);
		this.handleSubmit=this.handleSubmit.bind(this);
	}
	handleChange(event){
		//this.setState({value: event.target.value});
	}
	handleSubmit(event){
		//window.alert('submission made: ' + this.state.value); //Alert for testing
		sendData("oh hi mark", "dataTest");
		event.preventDefault();
	}
	render(){
		return ce('form', {onSubmit:this.handleSubmit, className:'aName'},
			[
			ce('p', {value:this.state.value}, null),
			ce('input', {type: 'text', value:this.state.value, onChange:this.handleChange}, null)
			]
		)
	}
}

ReactDOM.render([ce(testForm, null, null)], document.getElementById('main'));